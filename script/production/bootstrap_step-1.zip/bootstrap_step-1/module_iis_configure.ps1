param(
    # When set, skip the Hops plugin install step. Hops is a convenience for users
    # whose workflows depend on Grasshopper-definition-as-a-service; compute.geometry's
    # core Rhino API works fine without it. Skip is useful for headless bootstrap
    # contexts (SSM Session Manager, CI, unattended AMI builds, scheduled tasks)
    # where Start-Process -Credential as the freshly-created RhinoComputeUser crashes
    # the Yak install with STATUS_DLL_INIT_FAILED (exit code -1073741502) — the
    # CLR/COM initializers Yak loads need session/desktop state that -Credential
    # spawn doesn't provide in non-interactive contexts. Users who need Hops in a
    # skipped deployment can run 'yak install hops' manually after deployment.
    [switch]$SkipHopsInstall
)

# Env-var bridge: lets callers who invoke the bootstrap via boostrap_step-1.ps1
# (which doesn't accept params or pass them through) opt out of the Hops install
# by setting BOOTSTRAP_SKIP_HOPS=1 before launching the orchestrator.
if (-not $SkipHopsInstall -and $env:BOOTSTRAP_SKIP_HOPS -eq '1') {
    $SkipHopsInstall = $true
}

$appPoolName = "RhinoComputeAppPool"
$websiteName = "Rhino.Compute"
$physicalPathRoot = "C:\inetpub\wwwroot\aspnet_client\system_web\4_0_30319"
$rhinoComputePath = "$physicalPathRoot\rhino.compute"
$computeGeometryPath = "$physicalPathRoot\compute.geometry"
$localUserName = "RhinoComputeUser"

Import-Module WebAdministration

# Setup IIS to work with rhino.compute
#Requires -RunAsAdministrator

#Region funcs
function Write-Step { 
    Write-Host
    Write-Host "===> "$args[0] -ForegroundColor Green
    Write-Host
}
function CreateAppPool {
    Param([string] $appPoolName)
     if(Test-Path ("IIS:\AppPools\$appPoolName")) {
         Write-Host "The App Pool $appPoolName already exists"
         return
     }
     $appPool = New-WebAppPool -Name $appPoolName
}
function SetEnvVar {
    param (
        [Parameter(Mandatory=$true)][string] $name,
        [Parameter(Mandatory=$true)][string] $value,
        [switch] $secret = $false
    )
    $print = if ($secret) {"***"} else {$value}
    Write-Host "Setting environment variable: $name=$print"
    [System.Environment]::SetEnvironmentVariable($name, $value, "Machine")
}
function New-RandomPassword {
    param(
        [Parameter()]
        [int]$MinimumPasswordLength = 16,
        [Parameter()]
        [int]$MaximumPasswordLength = 20,
        [Parameter()]
        [int]$NumberOfAlphaNumericCharacters = 6,
        [Parameter()]
        [switch]$ConvertToSecureString
    )
    
    Add-Type -AssemblyName 'System.Web'
    $length = Get-Random -Minimum $MinimumPasswordLength -Maximum $MaximumPasswordLength
    $password = [System.Web.Security.Membership]::GeneratePassword($length,$NumberOfAlphaNumericCharacters)
    if ($ConvertToSecureString.IsPresent) {
        ConvertTo-SecureString -String $password -AsPlainText -Force
    } else {
        $password
    }
}
#EndRegion funcs

Write-Step "Creating a new user identity"
$securePassword = New-RandomPassword -MinimumPasswordLength 16 -MaximumPasswordLength 20 -NumberOfAlphaNumericCharacters 6 -ConvertToSecureString
$localUserAccount = @{
   Name = $localUserName
   Password = $securePassword
   Description = 'User identity passed to IIS RhinoComputeAppPool'
   AccountNeverExpires = $true
   PasswordNeverExpires = $true
   Verbose = $true
}
New-LocalUser @localUserAccount

Write-Step "Adding user to RDP user group"
Add-LocalGroupMember -Group "Remote Desktop Users" -Member $localUserName

$localUserPassword = (New-Object PSCredential $localUserName,$securePassword).GetNetworkCredential().Password
$securePassword = ConvertTo-SecureString $localUserPassword -AsPlainText -Force
$credential = New-Object System.Management.Automation.PSCredential($localUserName, $securePassword)

# The main script shows these after its transcript stops; restricted before the password is written.
Write-Step "Saving the $localUserName credentials to $credentialFile (Administrators only)"
New-Item -ItemType File -Path $credentialFile -Force | Out-Null
icacls $credentialFile /inheritance:r /grant:r "*S-1-5-32-544:(F)" "*S-1-5-18:(F)" | Out-Null
if ($LASTEXITCODE -ne 0) { throw "Couldn't restrict $credentialFile to Administrators (icacls exit code $LASTEXITCODE)." }
Set-Content -Path $credentialFile -Value @("User Name: $localUserName", "Password: $localUserPassword")

if ($SkipHopsInstall) {
    Write-Step "Skipping Hops plugin install (set by -SkipHopsInstall switch or BOOTSTRAP_SKIP_HOPS=1)"
    Write-Host "  Users who need Hops can install it after deployment via 'yak install hops'"
} else {
    Write-Step "Installing the Hops plugin"

    $yakPath = "C:\Program Files\Rhino 8\System\Yak.exe"
    $arguments = "install hops"

    # Use Start-Process with properly quoted arguments
    $process = Start-Process -FilePath $yakPath -ArgumentList $arguments -Credential $credential -WorkingDirectory "C:\Program Files\Rhino 8\System" -PassThru -Wait

    if ($process.ExitCode -ne 0) {
        throw "Failed to install the Hops plugin. Exit code: $($process.ExitCode)"
    }
}

Write-Step "Creating application pool"
CreateAppPool $appPoolName
Set-ItemProperty "IIS:\AppPools\$appPoolName" -Name "managedRuntimeVersion" -Value ""
Set-ItemProperty "IIS:\AppPools\$appPoolName" -Name "processModel.loadUserProfile" -Value "True"
Set-ItemProperty "IIS:\AppPools\$appPoolName" -Name "processModel.setProfileEnvironment" -Value "True"
Set-ItemProperty "IIS:\AppPools\$appPoolName" -Name "processModel" -value @{userName = $localUserName; password = $localUserPassword; identitytype = 3}

$node = Select-XML -Path "$rhinoComputePath\web.config" -XPath "//aspNetCore" | Select -ExpandProperty Node
$arguments = $node.arguments

if($arguments.Contains('idlespan'))
{
    $params = $arguments -split "--"
    foreach($i in $params)
    {
        if($i.Contains('idlespan'))
        {
            $values = $i -split " "
            Set-ItemProperty "IIS:\AppPools\$appPoolName" -Name "processModel.idleTimeout" -Value ([TimeSpan]::FromMinutes(($values[1]/60) + 5))
        }
    }
}
else
{
    Set-ItemProperty "IIS:\AppPools\$appPoolName" -Name "processModel.idleTimeout" -Value ([TimeSpan]::FromMinutes(65))
}

If((Test-Path "IIS:\Sites\Default Web Site"))
{
    Write-Step "Removing default website"
    Get-WebSite -Name "Default Web Site" | Remove-WebSite -Confirm:$false 
}

Write-Step "Creating new rhino.compute site"
If((Test-Path $rhinoComputePath))
{
    If(!(Test-Path "IIS:\Sites\$websiteName"))
    {
        New-WebSite -Name $websiteName -Id 2 -PhysicalPath $rhinoComputePath -ApplicationPool $appPoolName -Port 80 
        Set-ItemProperty "IIS:\Sites\$websiteName" -name applicationDefaults.preloadEnabled -value True
    }
    else {
        Write-Host "The IIS site $websiteName already exists"
    }
}

Write-Step "Granting application pool permissions on compute directories" 
cmd /c icacls $rhinoComputePath /grant ("IIS AppPool\$appPoolName" + ':(OI)(CI)F') /t /c /q 
cmd /c icacls $computeGeometryPath /grant ("IIS AppPool\$appPoolName"+ ':(OI)(CI)F') /t /c /q 

Write-Step "Setting environment variable for log paths"
SetEnvVar 'RHINO_COMPUTE_LOG_PATH' "$rhinoComputePath\logs"

Write-Step "Starting rhino.compute site" 
Start-IISSite -Name $websiteName
